# VIOREX — base de site

Esta é uma aplicação web com cadastro/login no servidor e banco SQLite. **Não é um sistema de investimentos e não recebe dinheiro.**

## Executar para testar
1. Instale Node.js 20 ou superior.
2. Abra a pasta no terminal.
3. Execute `npm install`.
4. Execute `npm start`.
5. Abra `http://localhost:3000`.

## Antes de publicar
- Hospede em servidor confiável com HTTPS.
- Defina `NODE_ENV=production`.
- Defina `SESSION_SECRET` com uma chave aleatória forte (mínimo 32 caracteres).
- Configure armazenamento persistente e backups do banco.
- Configure domínio, monitoramento, política de privacidade, termos e canal de suporte.
- Faça revisão de segurança independente.

## Recursos financeiros
Pix, depósitos, saques, saldo e promessa de rendimento não estão implementados. Não conecte uma chave Pix pessoal para receber dinheiro de clientes. Qualquer atividade de investimento/captação deve passar por análise jurídica e regulatória e usar um provedor autorizado, com controles de prevenção a fraude e lavagem de dinheiro.
