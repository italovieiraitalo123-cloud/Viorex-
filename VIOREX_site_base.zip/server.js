const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const db = new Database(process.env.DB_FILE || 'viorex.sqlite');
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.SESSION_SECRET;

if (isProd && (!sessionSecret || sessionSecret.length < 32)) {
  throw new Error('Defina SESSION_SECRET com pelo menos 32 caracteres antes de publicar.');
}

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
  name: 'viorex.sid',
  secret: sessionSecret || 'dev-only-change-this-secret-before-deploying',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 1000 * 60 * 60 * 8 }
}));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

function cleanEmail(value) {
  return String(value || '').trim().toLowerCase();
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Faça login para continuar.' });
  next();
}

app.post('/api/register', async (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = cleanEmail(req.body.email);
  const password = String(req.body.password || '');
  if (name.length < 2 || name.length > 70) return res.status(400).json({ error: 'Informe um nome válido.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 160) return res.status(400).json({ error: 'Informe um e-mail válido.' });
  if (password.length < 10 || password.length > 100) return res.status(400).json({ error: 'A senha precisa ter pelo menos 10 caracteres.' });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)').run(name, email, hash);
    req.session.userId = Number(result.lastInsertRowid);
    res.json({ ok: true, user: { name, email } });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'Este e-mail já está cadastrado.' });
    res.status(500).json({ error: 'Não foi possível criar a conta.' });
  }
});

app.post('/api/login', async (req, res) => {
  const email = cleanEmail(req.body.email);
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
  }
  req.session.userId = user.id;
  res.json({ ok: true, user: { name: user.name, email: user.email } });
});

app.get('/api/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT name,email,created_at FROM users WHERE id = ?').get(req.session.userId);
  if (!user) return res.status(401).json({ error: 'Sessão inválida.' });
  res.json({ user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'VIOREX' }));

app.listen(PORT, () => console.log(`VIOREX rodando em http://localhost:${PORT}`));
